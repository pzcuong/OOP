#include "CDiemKhongGian.h"

int main() {
	CDiemKhongGian DiemA, DiemB;
	cin >> DiemA >> DiemB;
	cout << DiemA << DiemB;
	if (DiemA == DiemB)
		cout << "2 diem trung nhau";
	else cout << "2 diem khong trung nhau";
	cout << DiemA.KhoangCach(DiemB);
}