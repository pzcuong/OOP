﻿#include "CDiemKhongGian.h"

void CDiemKhongGian::KhoiTao() {
	x = y = z = 0;
}

void CDiemKhongGian::KhoiTao(double xx, double yy, double zz) {
	x = xx;
	y = yy;
	z = zz;
}

void CDiemKhongGian::KhoiTao(const CDiemKhongGian& inp) {
	x = inp.x;
	y = inp.y;
	z = inp.z;
}

CDiemKhongGian::CDiemKhongGian() {
	x = y = z = 0;
}

CDiemKhongGian::CDiemKhongGian(double xx, double yy, double zz) {
	x = xx;
	y = yy;
	z = zz;
}

CDiemKhongGian::CDiemKhongGian(const CDiemKhongGian& inp) {
	x = inp.x;
	y = inp.y;
	z = inp.z;
}

void CDiemKhongGian::Nhap() {
	cout << "\nNhap x: ";
	cin >> x;
	cout << "Nhap y: ";
	cin >> y;
	cout << "Nhap z: ";
	cin >> z;
}

istream& operator>>(istream& is, CDiemKhongGian& inp) {
	cout << "\nNhap x: ";
	is >> inp.x;
	cout << "Nhap y: ";
	is >> inp.y;
	cout << "Nhap z: ";
	is >> inp.z;
	return is;
}

//Nhom phuong thuc cung cap thong tin
void CDiemKhongGian::Xuat() {
	cout << "\n (" << x << ", " << y << ", " << z << ")";
}

ostream& operator<<(ostream& os, CDiemKhongGian out) {
	os << "\n (" << out.x << ", " << out.y << ", " << out.z << ")\n";
	return os;
}

double CDiemKhongGian::getX() {
	return x;
}

double CDiemKhongGian::getY() {
	return y;
}

double CDiemKhongGian::getZ() {
	return z;
}
//Nhom phuong thuc cap nhat thong tin
CDiemKhongGian& CDiemKhongGian::operator=(const CDiemKhongGian& inp) {
	x = inp.x;
	y = inp.y;
	z = inp.z;
	return *this;
}

void CDiemKhongGian::setX(double xx) {
	x = xx;
}

void CDiemKhongGian::setY(double yy) {
	y = yy;
}

void CDiemKhongGian::setZ(double zz) {
	z = zz;
}
//Nhom phuong thuc kiem tra
int CDiemKhongGian::isTrungGocToaDo() {
	return (x == 0 && y == 0 && z == 0);
}

int CDiemKhongGian::isTrungNhau(const CDiemKhongGian& Diem) {
	return (x == Diem.x && y == Diem.y && z == Diem.z);
}

int CDiemKhongGian::isDoiXung(CDiemKhongGian Diem) {
	return (x == -Diem.x && y == -Diem.y && z == -Diem.z);
}

int CDiemKhongGian::ktThuocHoang() {
	return (y == 0 && z == 0);
}

int CDiemKhongGian::ktThuocTung() {
	return (z == 0 && x == 0);
}

int CDiemKhongGian::ktThuocCao() {
	return (x == 0 && y == 0);
}
//Nhom phuong thuc xu ly
double CDiemKhongGian::KhoangCachDenGocToaDo() {
	return sqrt(x * x + y * y + z * z);
}

double CDiemKhongGian::KhoangCach(CDiemKhongGian Diem) {
	return sqrt(pow(x - Diem.x, 2) + pow(y - Diem.y, 2) + pow(z - Diem.z, 2));
}

double CDiemKhongGian::KhoangCachPhuongOx(CDiemKhongGian Diem) {
	return abs(x - Diem.x);
}
double CDiemKhongGian::KhoangCachPhuongOy(CDiemKhongGian Diem) {
	return abs(y - Diem.y);
}
double CDiemKhongGian::KhoangCachPhuongOz(CDiemKhongGian Diem) {
	return abs(z - Diem.z);
}

int CDiemKhongGian::operator==(CDiemKhongGian Diem) {
	return (x == Diem.x && y == Diem.y && z == Diem.z);
}

int CDiemKhongGian::operator!=(CDiemKhongGian Diem) {
	return (!(x == Diem.x && y == Diem.y && z == Diem.z));
}

int CDiemKhongGian::operator>=(CDiemKhongGian Diem) {
	return (KhoangCachDenGocToaDo() >= Diem.KhoangCachDenGocToaDo());
}

int CDiemKhongGian::operator>(CDiemKhongGian Diem) {
	return (KhoangCachDenGocToaDo() > Diem.KhoangCachDenGocToaDo());

}
int CDiemKhongGian::operator<=(CDiemKhongGian Diem) {
	return (KhoangCachDenGocToaDo() <= Diem.KhoangCachDenGocToaDo());
}
int CDiemKhongGian::operator<(CDiemKhongGian Diem) {
	return (KhoangCachDenGocToaDo() < Diem.KhoangCachDenGocToaDo());
}
CDiemKhongGian::~CDiemKhongGian() {
	return;
}