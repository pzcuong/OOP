#include <iostream>
#include <cmath>
using namespace std;

class CDiemKhongGian {
private:
	double x, y, z;
public:
	//Nhom phuong thuc khoi tao
	void KhoiTao();
	void KhoiTao(double, double, double);
	void KhoiTao(const CDiemKhongGian&);
	CDiemKhongGian();
	CDiemKhongGian(double, double, double);
	CDiemKhongGian(const CDiemKhongGian&);
	void Nhap();
	friend istream& operator>>(istream&, CDiemKhongGian&);
	//Nhom phuong thuc cung cap thong tin
	void Xuat();
	friend ostream& operator<<(ostream&, CDiemKhongGian);
	double getX();
	double getY();
	double getZ();
	//Nhom phuong thuc cap nhat thong tin
	CDiemKhongGian& operator=(const CDiemKhongGian&);
	void setX(double);
	void setY(double);
	void setZ(double);
	//Nhom phuong thuc kiem tra
	int isTrungGocToaDo();
	int isTrungNhau(const CDiemKhongGian&);
	int isDoiXung(CDiemKhongGian);
	int ktThuocHoang();
	int ktThuocTung();
	int ktThuocCao();
	//Nhom phuong thuc xu ly
	double KhoangCachDenGocToaDo();
	double KhoangCach(CDiemKhongGian);
	double KhoangCachPhuongOx(CDiemKhongGian);
	double KhoangCachPhuongOy(CDiemKhongGian);
	double KhoangCachPhuongOz(CDiemKhongGian);
	int operator==(CDiemKhongGian);
	int operator!=(CDiemKhongGian);
	int operator>=(CDiemKhongGian);
	int operator>(CDiemKhongGian);
	int operator<=(CDiemKhongGian);
	int operator<(CDiemKhongGian);
	~CDiemKhongGian();
};

